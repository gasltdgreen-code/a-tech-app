export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>🚀 Green Gas App</h1>
      <p>Welcome! Your billing & reminder system is ready.</p>
      <button
        style={{
          background: "green",
          color: "white",
          padding: "10px 20px",
          borderRadius: "10px",
          border: "none",
          marginTop: "20px"
        }}
        onClick={() => alert("Reminder Sent!")}
      >
        Send Reminder
      </button>
    </div>
  );
}