"use client";
import ConsumerForm from '../components/ConsumerForm'

export default function AddPage() {
  return <ConsumerForm />
}
