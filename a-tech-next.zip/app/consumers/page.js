"use client";
import ConsumerList from '../components/ConsumerList'

export default function ConsumersPage() {
  return <ConsumerList />
}
