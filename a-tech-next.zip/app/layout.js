import './globals.css'

export const metadata = {
  title: 'A-Tech — Green Gas Billing',
  description: 'Local gas vendor billing & reminders app (PWA)'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#0e7b5f" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body>
        <nav className="sticky top-0 z-20 backdrop-blur bg-primary/95 text-white">
          <div className="container flex items-center gap-3 py-3">
            <div className="font-extrabold text-lg">A-Tech</div>
            <a className="mr-3" href="/">Dashboard</a>
            <a className="mr-3" href="/consumers">Consumers</a>
            <a className="mr-3" href="/add">Add</a>
            <a className="mr-3" href="/reminder">Reminder</a>
          </div>
        </nav>
        <div className="container">{children}</div>
        <script dangerouslySetInnerHTML={{__html:`
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js').catch(console.error);
            });
          }
        `}} />
      </body>
    </html>
  )
}
