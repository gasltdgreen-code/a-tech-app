"use client";
import { useEffect, useState } from 'react'
import { getAll } from '../lib/storage'

export default function Reminder() {
  const [list, setList] = useState([])
  const [daysBefore, setDaysBefore] = useState(0)

  useEffect(() => { setList(getAll()) }, [])

  const targets = list.filter(c => {
    if (!c.dueDate) return false
    const diffDays = Math.ceil((new Date(c.dueDate).getTime() - Date.now()) / (24*60*60*1000))
    return diffDays <= daysBefore && Number(c.balance||0) > 0
  })

  const waAll = () => {
    targets.forEach(c => {
      const msg = encodeURIComponent(`Reminder: ₹${c.balance||0} due on ${new Date(c.dueDate).toLocaleDateString()} — A-Tech`)
      window.open(`https://wa.me/${c.phone}?text=${msg}`, '_blank')
    })
  }

  return (
    <div className="card">
      <h3 className="font-bold text-lg">Reminders</h3>
      <div className="grid gap-3 items-center md:grid-cols-3">
        <div>
          <label>Days before due</label>
          <input type="number" className="border rounded-2xl px-3 py-2 w-full" value={daysBefore} onChange={e=>setDaysBefore(Number(e.target.value||0))} />
        </div>
        <button className="btn" onClick={waAll}>Send WhatsApp to all ({targets.length})</button>
      </div>
      <table className="mt-3">
        <thead><tr><th>Name</th><th>Phone</th><th>Balance</th><th>Due</th></tr></thead>
        <tbody>
          {targets.map((c,i) => (
            <tr key={i}>
              <td>{c.name}</td>
              <td><a className="text-primary" href={`tel:${c.phone}`}>{c.phone}</a></td>
              <td>₹{Number(c.balance||0).toFixed(2)}</td>
              <td>{new Date(c.dueDate).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
