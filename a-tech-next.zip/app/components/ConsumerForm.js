"use client";
import { useState } from 'react'
import { put } from '../lib/storage'

export default function ConsumerForm() {
  const [form, setForm] = useState({ name:'', phone:'', address:'', crn:'', lastReading:'', balance:0, dueDate:'' })
  const [ok, setOk] = useState('')

  const setField = (k, v) => setForm(prev => ({ ...prev, [k]: v }))

  const submit = (e) => {
    e.preventDefault()
    if (!form.name || !/^\d{10}$/.test(form.phone||'')) { alert('Name and 10-digit phone required'); return }
    const data = { ...form, balance: Number(form.balance||0) }
    put(data)
    setOk('Saved! Go to Consumers list to view.')
    setForm({ name:'', phone:'', address:'', crn:'', lastReading:'', balance:0, dueDate:'' })
  }

  return (
    <div className="card">
      <h3 className="font-bold text-lg">Add / Edit Consumer</h3>
      <form className="grid gap-3 md:grid-cols-2" onSubmit={submit}>
        <div><label>Name</label><input className="border rounded-2xl px-3 py-2 w-full" value={form.name} onChange={e=>setField('name', e.target.value)} placeholder="Customer name" /></div>
        <div><label>Phone</label><input className="border rounded-2xl px-3 py-2 w-full" value={form.phone} onChange={e=>setField('phone', e.target.value)} placeholder="10-digit" /></div>
        <div><label>Address</label><input className="border rounded-2xl px-3 py-2 w-full" value={form.address} onChange={e=>setField('address', e.target.value)} placeholder="Address" /></div>
        <div><label>CRN (optional)</label><input className="border rounded-2xl px-3 py-2 w-full" value={form.crn} onChange={e=>setField('crn', e.target.value)} placeholder="Consumer Ref No." /></div>
        <div><label>Last Reading</label><input className="border rounded-2xl px-3 py-2 w-full" value={form.lastReading} onChange={e=>setField('lastReading', e.target.value)} placeholder="e.g., 1245" /></div>
        <div><label>Balance (₹)</label><input type="number" className="border rounded-2xl px-3 py-2 w-full" value={form.balance} onChange={e=>setField('balance', e.target.value)} /></div>
        <div><label>Due Date</label><input type="date" className="border rounded-2xl px-3 py-2 w-full" value={form.dueDate} onChange={e=>setField('dueDate', e.target.value)} /></div>
        <div><button className="btn" type="submit">Save Consumer</button></div>
      </form>
      {ok && <p className="badge mt-3">{ok}</p>}
    </div>
  )
}
