"use client";
import { useEffect, useState } from 'react'
import { getAll } from '../lib/storage'

export default function Dashboard() {
  const [stats, setStats] = useState({ total: 0, pending: 0, overdue60: 0 })
  const [recent, setRecent] = useState([])

  useEffect(() => {
    const list = getAll()
    const total = list.length
    const pending = list.filter(c => Number(c.balance||0) > 0).length
    const overdue60 = list.filter(c => c.dueDate && (Date.now() - new Date(c.dueDate).getTime()) > 60*24*60*60*1000 && Number(c.balance||0) > 0).length
    setStats({ total, pending, overdue60 })
    setRecent(list.filter(c => Number(c.balance||0) > 0).slice(-5).reverse())
  }, [])

  return (
    <div className="grid gap-3">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="card"><div className="badge">Total Consumers</div><h2 className="text-2xl font-bold">{stats.total}</h2></div>
        <div className="card"><div className="badge">Pending Bills</div><h2 className="text-2xl font-bold">{stats.pending}</h2></div>
        <div className="card"><div className="badge">Priority 60+ days</div><h2 className="text-2xl font-bold">{stats.overdue60}</h2></div>
      </div>
      <div className="card">
        <h3 className="font-bold text-lg">Recent Unpaid</h3>
        {recent.length === 0 ? <div>All clear 🎉</div> : (
          <table className="mt-2">
            <thead><tr><th>Name</th><th>Phone</th><th>Balance</th><th>Due</th></tr></thead>
            <tbody>
              {recent.map((c,i) => (
                <tr key={i}>
                  <td>{c.name}</td>
                  <td><a className="text-primary" href={`tel:${c.phone}`}>{c.phone}</a></td>
                  <td>₹{Number(c.balance||0).toFixed(2)}</td>
                  <td>{c.dueDate ? new Date(c.dueDate).toLocaleDateString() : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
