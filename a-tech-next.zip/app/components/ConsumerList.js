"use client";
import { useEffect, useState } from 'react'
import { getAll, put, remove } from '../lib/storage'

export default function ConsumerList() {
  const [list, setList] = useState([])
  const [q, setQ] = useState('')
  const [onlyUnpaid, setOnlyUnpaid] = useState(false)

  const load = () => setList(getAll())
  useEffect(() => { load() }, [])

  const filtered = list.filter(c => {
    const match = (c.name||'').toLowerCase().includes(q.toLowerCase()) || (c.phone||'').includes(q)
    const unpaidOk = !onlyUnpaid || Number(c.balance||0) > 0
    return match && unpaidOk
  })

  const markPaid = (c) => {
    const amt = Number(prompt('Amount received (₹)?', c.balance||0) || 0)
    if (isNaN(amt) || amt <= 0) return
    const bal = Math.max(0, Number(c.balance||0) - amt)
    const payments = [...(c.payments||[]), { date: Date.now(), amount: amt }]
    put({ ...c, balance: bal, payments })
    load()
  }

  const wa = (c) => {
    const msg = encodeURIComponent(`Dear ${c.name}, your gas bill is ₹${c.balance||0}. Due: ${c.dueDate ? new Date(c.dueDate).toLocaleDateString() : 'NA'} — A-Tech`)
    window.open(`https://wa.me/${c.phone}?text=${msg}`, '_blank')
  }

  const sms = (c) => {
    const body = encodeURIComponent(`Bill: ₹${c.balance||0}. Due: ${c.dueDate ? new Date(c.dueDate).toLocaleDateString() : 'NA'} — A-Tech`)
    window.location.href = `sms:${c.phone}?body=${body}`
  }

  return (
    <div className="card">
      <div className="grid gap-2 mb-3 md:grid-cols-3">
        <input placeholder="Search by name/phone" value={q} onChange={e=>setQ(e.target.value)} className="border rounded-2xl px-3 py-2" />
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={onlyUnpaid} onChange={e=>setOnlyUnpaid(e.target.checked)} /> Only unpaid
        </label>
      </div>
      <table>
        <thead><tr><th>Name</th><th>Phone</th><th>CRN</th><th>Balance</th><th>Due</th><th>Actions</th></tr></thead>
        <tbody>
          {filtered.map((c,i) => (
            <tr key={i}>
              <td>{c.name} {(!c.crn) && <span className="badge">CRN missing</span>}</td>
              <td><a className="text-primary" href={`tel:${c.phone}`}>{c.phone}</a></td>
              <td>{c.crn || '-'}</td>
              <td>₹{Number(c.balance||0).toFixed(2)}</td>
              <td>{c.dueDate ? new Date(c.dueDate).toLocaleDateString() : '-'}</td>
              <td className="flex gap-2 flex-wrap py-2">
                <button className="btn" onClick={() => wa(c)}>WhatsApp</button>
                <button className="btn btn-secondary" onClick={() => sms(c)}>SMS</button>
                <button className="btn" onClick={() => markPaid(c)}>Mark Paid / Partial</button>
                <button className="btn btn-secondary" onClick={() => { remove(c); load(); }}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
