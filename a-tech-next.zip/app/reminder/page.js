"use client";
import Reminder from '../components/ReminderSection'

export default function ReminderPage() {
  return <Reminder />
}
