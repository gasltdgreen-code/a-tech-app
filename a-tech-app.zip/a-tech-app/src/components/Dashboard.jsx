import React, { useEffect, useState } from 'react'
import { getConsumers } from '../db'

export default function Dashboard() {
  const [stats, setStats] = useState({ total: 0, pending: 0, overdue60: 0 })
  const [recent, setRecent] = useState([])

  useEffect(() => {
    (async () => {
      const list = await getConsumers()
      const total = list.length
      const pending = list.filter(c => (c.balance || 0) > 0).length
      const overdue60 = list.filter(c => c.dueDate && (Date.now() - new Date(c.dueDate).getTime()) > 60*24*60*60*1000 && (c.balance||0) > 0).length
      setStats({ total, pending, overdue60 })
      setRecent(list.filter(c => (c.balance||0) > 0).slice(-5).reverse())
    })()
  }, [])

  return (
    <div className="grid">
      <div className="grid cols-3">
        <div className="card"><div className="badge">Total Consumers</div><h2>{stats.total}</h2></div>
        <div className="card"><div className="badge">Pending Bills</div><h2>{stats.pending}</h2></div>
        <div className="card"><div className="badge">Priority 60+ days</div><h2>{stats.overdue60}</h2></div>
      </div>
      <div className="card">
        <h3 style={{marginTop:0}}>Recent Unpaid</h3>
        {recent.length === 0 ? <div>All clear 🎉</div> : (
          <table>
            <thead><tr><th>Name</th><th>Phone</th><th>Balance</th><th>Due</th></tr></thead>
            <tbody>
              {recent.map(c => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td><a href={`tel:${c.phone}`}>{c.phone}</a></td>
                  <td>₹{Number(c.balance||0).toFixed(2)}</td>
                  <td>{c.dueDate ? new Date(c.dueDate).toLocaleDateString() : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
