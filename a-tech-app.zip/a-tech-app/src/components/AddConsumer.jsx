import React, { useState } from 'react'
import { addConsumer } from '../db'

export default function AddConsumer() {
  const [form, setForm] = useState({ name:'', phone:'', address:'', crn:'', lastReading:'', balance:0, dueDate:'' })
  const [ok, setOk] = useState('')

  const set = (k, v) => setForm(prev => ({ ...prev, [k]: v }))

  const submit = async (e) => {
    e.preventDefault()
    if (!form.name || !/^\d{10}$/.test(form.phone||'')) {
      alert('Name and 10‑digit phone are required'); return
    }
    const data = { ...form, balance: Number(form.balance||0) }
    await addConsumer(data)
    setOk('Saved! Go to Consumers list to view.')
    setForm({ name:'', phone:'', address:'', crn:'', lastReading:'', balance:0, dueDate:'' })
  }

  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Add / Edit Consumer</h3>
      <form className="grid" onSubmit={submit}>
        <div>
          <label>Name</label>
          <input value={form.name} onChange={e=>set('name', e.target.value)} placeholder="Customer name" />
        </div>
        <div>
          <label>Phone</label>
          <input value={form.phone} onChange={e=>set('phone', e.target.value)} placeholder="10‑digit" />
        </div>
        <div>
          <label>Address</label>
          <input value={form.address} onChange={e=>set('address', e.target.value)} placeholder="Address" />
        </div>
        <div>
          <label>CRN (optional)</label>
          <input value={form.crn} onChange={e=>set('crn', e.target.value)} placeholder="Consumer Ref No." />
        </div>
        <div>
          <label>Last Reading</label>
          <input value={form.lastReading} onChange={e=>set('lastReading', e.target.value)} placeholder="e.g., 1245" />
        </div>
        <div>
          <label>Balance (₹)</label>
          <input type="number" value={form.balance} onChange={e=>set('balance', e.target.value)} />
        </div>
        <div>
          <label>Due Date</label>
          <input type="date" value={form.dueDate} onChange={e=>set('dueDate', e.target.value)} />
        </div>
        <div>
          <button className="btn" type="submit">Save Consumer</button>
        </div>
      </form>
      {ok && <p className="badge" style={{marginTop:12}}>{ok}</p>}
    </div>
  )
}
