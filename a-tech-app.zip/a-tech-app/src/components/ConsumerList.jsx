import React, { useEffect, useState } from 'react'
import { getConsumers, updateConsumer, deleteConsumer } from '../db'

export default function ConsumerList() {
  const [list, setList] = useState([])
  const [q, setQ] = useState('')
  const [onlyUnpaid, setOnlyUnpaid] = useState(false)

  const load = async () => setList(await getConsumers())
  useEffect(() => { load() }, [])

  const filtered = list.filter(c => {
    const match = (c.name||'').toLowerCase().includes(q.toLowerCase()) || (c.phone||'').includes(q)
    const unpaidOk = !onlyUnpaid || (c.balance||0) > 0
    return match && unpaidOk
  })

  const markPaid = async (c) => {
    const amt = Number(prompt('Amount received (₹)?', c.balance||0) || 0)
    if (isNaN(amt) || amt <= 0) return
    const bal = Math.max(0, (c.balance||0) - amt)
    const payments = [...(c.payments||[]), { date: Date.now(), amount: amt }]
    await updateConsumer({ ...c, balance: bal, payments })
    load()
  }

  const remove = async (id) => {
    if (confirm('Delete this consumer?')) {
      await deleteConsumer(id); load()
    }
  }

  const wa = (c) => {
    const msg = encodeURIComponent(`Dear ${c.name}, your gas bill is ₹${c.balance||0}. Due: ${c.dueDate ? new Date(c.dueDate).toLocaleDateString() : 'NA'} — A‑Tech`)
    window.open(`https://wa.me/${c.phone}?text=${msg}`, '_blank')
  }

  const sms = (c) => {
    const body = encodeURIComponent(`Bill: ₹${c.balance||0}. Due: ${c.dueDate ? new Date(c.dueDate).toLocaleDateString() : 'NA'} — A‑Tech`)
    window.location.href = `sms:${c.phone}?body=${body}`
  }

  return (
    <div className="card">
      <div className="grid" style={{marginBottom:12}}>
        <input placeholder="Search by name/phone" value={q} onChange={e=>setQ(e.target.value)} />
        <label style={{display:'flex',alignItems:'center',gap:8}}>
          <input type="checkbox" checked={onlyUnpaid} onChange={e=>setOnlyUnpaid(e.target.checked)} /> Only unpaid
        </label>
      </div>
      <table>
        <thead><tr><th>Name</th><th>Phone</th><th>CRN</th><th>Balance</th><th>Due</th><th>Actions</th></tr></thead>
        <tbody>
          {filtered.map(c => (
            <tr key={c.id}>
              <td>{c.name} {(!c.crn) && <span className="badge">CRN missing</span>}</td>
              <td><a href={`tel:${c.phone}`}>{c.phone}</a></td>
              <td>{c.crn || '-'}</td>
              <td>₹{Number(c.balance||0).toFixed(2)}</td>
              <td>{c.dueDate ? new Date(c.dueDate).toLocaleDateString() : '-'}</td>
              <td style={{display:'flex',gap:8, flexWrap:'wrap'}}>
                <button className="btn" onClick={() => wa(c)}>WhatsApp</button>
                <button className="btn secondary" onClick={() => sms(c)}>SMS</button>
                <button className="btn" onClick={() => markPaid(c)}>Mark Paid / Partial</button>
                <button className="btn secondary" onClick={() => remove(c.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
