import React, { useEffect, useState } from 'react'
import { getConsumers } from '../db'

export default function Reminder() {
  const [list, setList] = useState([])
  const [daysBefore, setDaysBefore] = useState(0)

  useEffect(() => { (async () => setList(await getConsumers()))() }, [])

  const targets = list.filter(c => {
    if (!c.dueDate) return false
    const diffDays = Math.ceil((new Date(c.dueDate).getTime() - Date.now()) / (24*60*60*1000))
    return diffDays <= daysBefore && (c.balance||0) > 0
  })

  const waAll = () => {
    targets.forEach(c => {
      const msg = encodeURIComponent(`Reminder: ₹${c.balance||0} due on ${new Date(c.dueDate).toLocaleDateString()} — A‑Tech`)
      window.open(`https://wa.me/${c.phone}?text=${msg}`, '_blank')
    })
  }

  return (
    <div className="card">
      <h3 style={{marginTop:0}}>Reminders</h3>
      <div className="grid" style={{alignItems:'center'}}>
        <div>
          <label>Days before due</label>
          <input type="number" value={daysBefore} onChange={e=>setDaysBefore(Number(e.target.value||0))} />
        </div>
        <button className="btn" onClick={waAll}>Send WhatsApp to all ({targets.length})</button>
      </div>
      <table style={{marginTop:12}}>
        <thead><tr><th>Name</th><th>Phone</th><th>Balance</th><th>Due</th></tr></thead>
        <tbody>
          {targets.map(c => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td><a href={`tel:${c.phone}`}>{c.phone}</a></td>
              <td>₹{Number(c.balance||0).toFixed(2)}</td>
              <td>{new Date(c.dueDate).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
