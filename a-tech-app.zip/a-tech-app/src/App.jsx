import React from 'react'
import { Routes, Route, Link, useLocation } from 'react-router-dom'
import Dashboard from './components/Dashboard'
import ConsumerList from './components/ConsumerList'
import AddConsumer from './components/AddConsumer'
import Reminder from './components/Reminder'

function Nav() {
  const loc = useLocation()
  const active = (p) => ({ fontWeight: loc.pathname === p ? 700 : 500 })
  return (
    <nav>
      <div className="nav-inner">
        <div style={{ fontSize: 20, fontWeight: 800 }}>A‑Tech</div>
        <Link to="/" style={active('/')}>Dashboard</Link>
        <Link to="/consumers" style={active('/consumers')}>Consumers</Link>
        <Link to="/add" style={active('/add')}>Add</Link>
        <Link to="/reminder" style={active('/reminder')}>Reminder</Link>
      </div>
    </nav>
  )
}

export default function App() {
  return (
    <div>
      <Nav />
      <div className="container">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/consumers" element={<ConsumerList />} />
          <Route path="/add" element={<AddConsumer />} />
          <Route path="/reminder" element={<Reminder />} />
        </Routes>
      </div>
    </div>
  )
}
