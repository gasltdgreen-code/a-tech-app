import { openDB } from 'idb'

const DB_NAME = 'AtechDB'
const C_STORE = 'consumers'

export async function getDB() {
  return openDB(DB_NAME, 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(C_STORE)) {
        const store = db.createObjectStore(C_STORE, { keyPath: 'id', autoIncrement: true })
        store.createIndex('name', 'name', { unique: false })
        store.createIndex('phone', 'phone', { unique: false })
        store.createIndex('unpaid', 'unpaid', { unique: false })
      }
    }
  })
}

export async function addConsumer(data) {
  const db = await getDB()
  data.createdAt = Date.now()
  data.unpaid = (data.balance || 0) > 0
  data.payments = data.payments || []
  return db.add(C_STORE, data)
}

export async function updateConsumer(data) {
  const db = await getDB()
  data.unpaid = (data.balance || 0) > 0
  return db.put(C_STORE, data)
}

export async function getConsumers() {
  const db = await getDB()
  return db.getAll(C_STORE)
}

export async function deleteConsumer(id) {
  const db = await getDB()
  return db.delete(C_STORE, id)
}
